// Copyright (c) Microsoft Corporation. All rights reserved.
// SPDX-License-Identifier: MIT

// Placeholder for int test_iot_provisioning_(); declarations

int test_az_iot_provisioning_client();
int test_az_iot_provisioning_client_sas_token();
int test_az_iot_provisioning_client_parser();
int test_az_iot_provisioning_client_payload();
