// Copyright (c) Microsoft Corporation. All rights reserved.
// SPDX-License-Identifier: MIT

int test_az_iot_hub_client();
int test_az_iot_hub_client_c2d();
int test_az_iot_hub_client_methods();
int test_az_iot_hub_client_sas_token();
int test_az_iot_hub_client_telemetry();
int test_az_iot_hub_client_twin();
int test_az_iot_hub_client_telemetry_with_component();
int test_az_iot_hub_client_commands();
int test_az_iot_hub_client_properties();
