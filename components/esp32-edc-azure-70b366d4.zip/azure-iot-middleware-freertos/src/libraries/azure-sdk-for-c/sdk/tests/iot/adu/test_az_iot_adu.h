// Copyright (c) Microsoft Corporation. All rights reserved.
// SPDX-License-Identifier: MIT

int test_az_iot_adu();
