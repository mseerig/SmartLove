---
page_type: sample
languages:
  - c
products:
  - azure
urlFragment: core-samples
---

# Azure Core Samples client Library for Embedded C

This document explains samples and how to use them.

## Key Concepts

## Getting Sarted

## Examples

## Troubleshooting

## Next Steps

### Additional Documentation

## Contributing

This project welcomes contributions and suggestions. Find [more contributing][SDK_README_CONTRIBUTING] details here.

<!-- LINKS -->
[SDK_README_CONTRIBUTING]: https://github.com/Azure/azure-sdk-for-c/blob/main/CONTRIBUTING.md

![Impressions](https://azure-sdk-impressions.azurewebsites.net/api/impressions/azure-sdk-for-c%2Fsdk%2Fcore%2Fcore%2Fsamples%2FREADME.png)
